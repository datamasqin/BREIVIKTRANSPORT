**Privacy Policy**

Stefano Bertoli built the KHabit app as an Open Source app, and this app does not ask or collect any personal data from the user.

The app stores all its data locally on the user device and sync it with the user's personal iCloud account.

The developer of this app can not, in any way, read or use any data from the user.

This policy is effective as of 2020-10-03


**Contact Us**

If you have any questions or suggestions about my Privacy Policy, do not hesitate to contact me at stefanokiwy at gmail dot com.
